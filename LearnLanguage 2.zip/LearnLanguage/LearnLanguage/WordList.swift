//
//  WordList.swift
//  LearnLanguage
//
//  Created by iOS Student on 11/16/16.
//  Copyright © 2016 PIRATE. All rights reserved.
//

import UIKit

class WordList: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tbvWordList: UITableView!

    
    @IBOutlet var mySearchBar: UISearchBar!

    var tap: UITapGestureRecognizer?
    var searchController : UISearchController!
    var languageid: Int!
    
    var dbWord = [NSDictionary]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mySearchBar.backgroundColor = UIColor.lightGray
        
        self.navigationController?.navigationBar.isTranslucent = false
        
        
        let cellWord = UINib(nibName: "CellWord", bundle: nil)
        self.tbvWordList.register(cellWord, forCellReuseIdentifier: "Cell1")
        
        let btn2 = UIButton(frame: CGRect(x: 0, y: 0, width: 30, height: 30))
        btn2.setImage(UIImage(named: "imgback.ico"), for: .normal)
        btn2.addTarget(self, action: #selector(Dismiss), for: .touchUpInside)
        
        let backbtn = UIBarButtonItem(customView: btn2)
        
        navigationItem.setLeftBarButton(backbtn, animated: true)
        
        let add = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addWord))
        navigationItem.setRightBarButton(add, animated: true)
        
        tap  = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        mySearchBar.setShowsCancelButton(false, animated: true)
        
    
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let database = DataBase.sharedInstance
        dbWord = database.viewDatabase("WORD", columns: ["ID","LANGUAGEID","NameWord","Mean","WordForm","Image","Bool"], statement: "WHERE LanguageID = \( languageid! )")
        self.tbvWordList.reloadData()
    }
    
    func Dismiss(){
        navigationController?.dismiss(animated: true, completion: nil)
    }
    
    func addWord(){
        
        let addWordVC = AddWordVC(nibName: "AddWordVC", bundle: nil)
        addWordVC.languageid = languageid
        navigationController?.pushViewController(addWordVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dbWord.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell1", for: indexPath) as! CellWord
        let item = dbWord[(indexPath as NSIndexPath).row] as! [String:Any]
        cell.textLabel?.text = "\(item["NameWord"] as! String)"
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(dbWord)
        let item = dbWord[(indexPath as NSIndexPath).row] as! [String:Any]
        let detailVC = DetailWordVC(nibName: "DetailWordVC", bundle: nil)
        detailVC.str1 = item["NameWord"] as? String
        detailVC.str2 = item["WordForm"] as? String
        detailVC.str3 = item["Mean"] as? String
        detailVC.image = item["Image"] as? String
        displayPopupDetail(detailVC)
        
   
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let delete = DataBase.sharedInstance
            let item = dbWord[(indexPath.row)]
            delete.deleteDatabase("WORD", ID: ((item["ID"] as? Int)!))
            dbWord.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
         //   print(dbWord)
        }
    }
    
    //MARK: Create POPUP
    
    var popupVC: DetailWordVC?
    var blurView: UIView?
    
    func makeBlurMainView() -> UIView {
        let blurView = UIView(frame: tbvWordList.bounds)
        blurView.alpha = 0.3
        blurView.backgroundColor = UIColor.black
        
        return blurView
    }
    
    func displayPopupDetail(_ content: DetailWordVC){
        popupVC = content
        blurView = makeBlurMainView()
        
        let dismissTapGesture = UITapGestureRecognizer(target: self, action: #selector(tapDismissGesture(_:)))
        blurView?.addGestureRecognizer(dismissTapGesture)
        
        view.addSubview(blurView!)
        addChildViewController(content)
        
        UIView.animate(withDuration: 0.3, delay: 0.0, options: UIViewAnimationOptions.transitionFlipFromTop, animations: {
            content.view.alpha = 1.0
            content.view.center = CGPoint(x: self.view.bounds.width/2.0, y: self.view.bounds.height/2.0)
            self.view.addSubview(content.view)
            content.didMove(toParentViewController: self)
            
            }, completion: nil)
    }
    
    func animateDismissPopupView(_ addNewVC : DetailWordVC) {
        
        UIView.animate(withDuration: 0.5, delay: 0.0, options: UIViewAnimationOptions(), animations: {
            
            addNewVC.view.alpha = 0.5
            addNewVC.view.center = CGPoint(x: self.view.bounds.width / 2.0, y: -self.view.bounds.height)
            self.blurView?.alpha = 0.0
            
        }){(Bool) in
            addNewVC.view.removeFromSuperview()
            addNewVC.removeFromParentViewController()
            self.blurView?.removeFromSuperview()
        }
        
    }
    func tapDismissGesture(_ tapGesture : UITapGestureRecognizer) {
        animateDismissPopupView(popupVC!)
    }
    
    
}

extension WordList : UISearchBarDelegate{
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        dismissKeyboard()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        mySearchBar.setShowsCancelButton(true, animated: true)
        tbvWordList.addGestureRecognizer(tap!)
        let uibuton = searchBar.value(forKey: "cancelButton") as! UIButton
        uibuton.setTitleColor(UIColor.blue, for: .normal)
    }
    
    func dismissKeyboard() {
        mySearchBar.setShowsCancelButton(false, animated: true)
        tbvWordList.removeGestureRecognizer(tap!)
        mySearchBar.endEditing(true)
        mySearchBar.text = ""
    }
    
    
}
