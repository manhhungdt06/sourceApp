//
//  CellRecorder.swift
//  LearnLanguage
//
//  Created by PIRATE on 11/21/16.
//  Copyright © 2016 PIRATE. All rights reserved.
//

import UIKit

class CellRecorder: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
