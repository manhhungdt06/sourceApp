//
//  DetailWordVC.swift
//  LearnLanguage
//
//  Created by iOS Student on 11/29/16.
//  Copyright © 2016 PIRATE. All rights reserved.
//

import UIKit

class DetailWordVC: UIViewController {
    @IBOutlet weak var nameWord: UILabel!
    @IBOutlet weak var wordForm: UILabel!
    @IBOutlet weak var meanWord: UILabel!
    @IBOutlet weak var imgWord: UIImageView!

    var str1: String?
    var str2: String?
    var str3: String?
    var image: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.nameWord.text = str1
        self.wordForm.text = str2
        self.meanWord.text = str3

        self.imgWord.image = UIImage(named: image)
      
    }

    @IBAction func btn_record(_ sender: AnyObject) {
    }
   

}
