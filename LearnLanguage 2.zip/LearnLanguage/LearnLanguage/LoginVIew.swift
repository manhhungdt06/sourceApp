//
//  LoginVIew.swift
//  LearnLanguage
//
//  Created by PIRATE on 12/6/16.
//  Copyright © 2016 PIRATE. All rights reserved.
//

import UIKit

class LoginVIew: UIViewController {

    @IBOutlet weak var usernameT: UITextField!
    
    @IBOutlet weak var passT: UITextField!
    
    @IBAction func loginAct(_ sender: Any) {
        let mainview = TableLanguage(nibName: "TableLanguage", bundle: nil)
        let navi = BaseNavigationController(rootViewController: mainview)
        
        present(navi, animated: true, completion: nil)
    }
    @IBOutlet weak var loginBtn: UIButton!
     override func viewDidLoad() {
        super.viewDidLoad()
        
        loginBtn.layer.cornerRadius = 10
        loginBtn.clipsToBounds = true
        
        usernameT.layer.cornerRadius = 15
        usernameT.clipsToBounds = true
        
        passT.layer.cornerRadius = 15
        passT.clipsToBounds = true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
           }
    
}
