//
//  addLanguage.swift
//  Learning-Language
//
//  Created by PIRATE on 11/11/16.
//  Copyright © 2016 Duong. All rights reserved.
//

import UIKit

class addLanguage: UIViewController , UIImagePickerControllerDelegate , UINavigationControllerDelegate {
    
    var backTablelanguage : TableLanguage!
    let database = DataBase.sharedInstance
     var baseImage = UIImage()
    @IBOutlet weak var nameLanguage: UITextField!
    
    @IBOutlet weak var imageLanguage: UIImageView!
    
    @IBAction func BrowseImage(_ sender: AnyObject) {
        let imgPicker = UIImagePickerController()
        imgPicker.delegate = self
        imgPicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        self.present(imgPicker, animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickImage: UIImage = (info[UIImagePickerControllerOriginalImage]) as? UIImage
        {
            baseImage = pickImage
            imageLanguage.image = baseImage
        }
    }
    
    @IBAction func updateLanguage(_ sender: AnyObject) {
        
        backTablelanguage = TableLanguage(nibName: "TableLanguage", bundle: nil)
        let doccumentsDirectoryURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        print(doccumentsDirectoryURL)
        let urlImage = doccumentsDirectoryURL.absoluteString + nameLanguage.text!
        print(urlImage)
        database.insertDataBase("Language",  dict: ["LanguageName":nameLanguage.text! ,"UrlImg": urlImage ])
        self.navigationController?.pushViewController(backTablelanguage, animated: true)
               writeImage(path: doccumentsDirectoryURL, imageName: nameLanguage.text!, image: baseImage)
    }
    
    func writeImage(path : URL, imageName : String, image : UIImage) {
      
        let newPath = path.appendingPathComponent(imageName)
        
        do {
            try UIImagePNGRepresentation(image)?.write(to: newPath)
        } catch let error as NSError {
            print(error.localizedDescription)
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    
}
