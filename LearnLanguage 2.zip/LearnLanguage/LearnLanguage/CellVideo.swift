//
//  CellVideo.swift
//  LearnLanguage
//
//  Created by PIRATE on 11/30/16.
//  Copyright © 2016 PIRATE. All rights reserved.
//

import UIKit

class CellVideo: UITableViewCell {

    @IBOutlet weak var nameVideo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
